import React from 'react';

const About: React.FC = () => {
  return (
    <section
      id="about"
      className="py-20 bg-white dark:bg-gray-900"
    >
      <div className="container mx-auto px-4 md:px-8">
        <div className="flex flex-col md:flex-row items-center">
          <div className="w-full md:w-1/2 mb-12 md:mb-0">
            <div className="relative">
              <div className="w-72 h-72 md:w-80 md:h-80 lg:w-96 lg:h-96 relative mx-auto">
                <div className="absolute inset-0 bg-blue-600 rounded-full opacity-20 blur-2xl transform-gpu"></div>
                <img
                  src="https://images.pexels.com/photos/3861959/pexels-photo-3861959.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                  alt="Creative designer portrait"
                  className="relative rounded-full object-cover w-full h-full border-4 border-white dark:border-gray-800 shadow-lg"
                />
              </div>
            </div>
          </div>
          <div className="w-full md:w-1/2 md:pl-12">
            <div className="text-sm font-semibold text-blue-600 dark:text-blue-400 uppercase tracking-wider mb-4">
              About Me
            </div>
            <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-6">
              Creative Web Developer Crafting Digital Experiences
            </h2>
            <p className="text-gray-700 dark:text-gray-300 mb-6 text-lg">
              I'm a creative web developer with 5+ years of experience crafting beautiful, functional, and user-centered digital experiences. I combine technical expertise with creative problem-solving to build websites and applications that deliver real value.
            </p>
            <p className="text-gray-700 dark:text-gray-300 mb-8 text-lg">
              With a strong focus on responsive design, performance optimization, and clean code, I create digital solutions that help businesses achieve their goals. When I'm not coding, you'll find me exploring new technologies, contributing to open-source projects, or sharing knowledge with the developer community.
            </p>
            <div className="flex flex-wrap gap-4">
              <div className="px-6 py-3 bg-gray-100 dark:bg-gray-800 rounded-lg">
                <div className="text-xl font-bold text-blue-600 dark:text-blue-400">5+</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Years Experience</div>
              </div>
              <div className="px-6 py-3 bg-gray-100 dark:bg-gray-800 rounded-lg">
                <div className="text-xl font-bold text-blue-600 dark:text-blue-400">50+</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Projects Completed</div>
              </div>
              <div className="px-6 py-3 bg-gray-100 dark:bg-gray-800 rounded-lg">
                <div className="text-xl font-bold text-blue-600 dark:text-blue-400">30+</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Happy Clients</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;